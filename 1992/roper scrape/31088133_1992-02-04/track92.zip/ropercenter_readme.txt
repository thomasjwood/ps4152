Fips codes erased 9/22/04.

Located in 1/14-18 in CW16T17C to CW12T14C
and located in 1/16-20 CW11T13C to CW4T6C. 
